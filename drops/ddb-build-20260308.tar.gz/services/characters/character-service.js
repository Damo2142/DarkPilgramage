/**
 * character-service.js
 * Loads DDB-synced character JSON files into Co-DM game state.
 * Characters live in config/characters/{ddbId}.json
 * Players are assigned to characters via config/character-assignments.json
 */

const fs = require('fs');
const path = require('path');

class CharacterService {
  constructor() {
    this.name = 'characters';
    this.orchestrator = null;
    this.charactersDir = null;
    this.assignmentsPath = null;
  }

  async init(orchestrator) {
    this.orchestrator = orchestrator;
    this.bus = orchestrator.bus;
    this.state = orchestrator.state;
    this.config = orchestrator.config;

    const configDir = path.resolve(this.config.configDir || './config');
    this.charactersDir = path.join(configDir, 'characters');
    this.assignmentsPath = path.join(configDir, 'character-assignments.json');

    fs.mkdirSync(this.charactersDir, { recursive: true });
  }

  async start() {
    const loaded = this._loadAll();
    console.log(`[Characters] Loaded ${loaded} character(s) into game state`);
  }

  async stop() {}

  /**
   * Load all character files and push them into game state.
   * Assignments file maps playerId → ddbCharacterId.
   */
  _loadAll() {
    const characters = this._readCharacterFiles();
    const assignments = this._readAssignments();
    let count = 0;

    for (const [playerId, ddbId] of Object.entries(assignments)) {
      const char = characters[String(ddbId)];
      if (!char) {
        console.warn(`[Characters] Assignment: player '${playerId}' → DDB ID ${ddbId} — file not found`);
        continue;
      }
      this.state.setPlayer(playerId, {
        name: playerId,
        character: char
      });
      console.log(`[Characters] → ${playerId}: ${char.name} (${char.race} ${char.class} ${char.level})`);
      count++;
    }

    // Also put any unassigned characters in state for dashboard visibility
    this.state.set('characters.available', characters);

    return count;
  }

  _readCharacterFiles() {
    const chars = {};
    if (!fs.existsSync(this.charactersDir)) return chars;

    for (const file of fs.readdirSync(this.charactersDir)) {
      if (!file.endsWith('.json')) continue;
      try {
        const data = JSON.parse(fs.readFileSync(path.join(this.charactersDir, file), 'utf8'));
        const id = data.ddbId || path.basename(file, '.json');
        chars[String(id)] = data;
      } catch (err) {
        console.warn(`[Characters] Failed to parse ${file}: ${err.message}`);
      }
    }
    return chars;
  }

  _readAssignments() {
    if (!fs.existsSync(this.assignmentsPath)) return {};
    try {
      return JSON.parse(fs.readFileSync(this.assignmentsPath, 'utf8'));
    } catch (err) {
      console.warn(`[Characters] Could not read assignments: ${err.message}`);
      return {};
    }
  }

  /**
   * Reload all character files without restarting.
   * Called by the /api/characters/reload endpoint.
   */
  reload() {
    const loaded = this._loadAll();
    this.bus.dispatch('characters:reloaded', { count: loaded });
    return loaded;
  }

  /**
   * Assign a player to a DDB character.
   * Persists to character-assignments.json.
   */
  assign(playerId, ddbId) {
    const assignments = this._readAssignments();
    assignments[playerId] = String(ddbId);
    fs.writeFileSync(this.assignmentsPath, JSON.stringify(assignments, null, 2));
    this.reload();
    return assignments;
  }

  /**
   * Remove a player assignment.
   */
  unassign(playerId) {
    const assignments = this._readAssignments();
    delete assignments[playerId];
    fs.writeFileSync(this.assignmentsPath, JSON.stringify(assignments, null, 2));
    return assignments;
  }

  getStatus() {
    const chars = this._readCharacterFiles();
    const assignments = this._readAssignments();
    return {
      name: this.name,
      status: 'running',
      charactersLoaded: Object.keys(chars).length,
      assigned: Object.keys(assignments).length,
      characters: Object.values(chars).map(c => ({
        ddbId: c.ddbId,
        name: c.name,
        class: c.class,
        level: c.level,
        race: c.race,
        syncedAt: c._syncedAt
      })),
      assignments
    };
  }
}

module.exports = CharacterService;
