#!/bin/bash
# setup-systemd.sh — Install and enable the co-dm systemd service
# Run as dave from ~/dark-pilgrimage/co-dm/

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVICE_NAME="co-dm"
SERVICE_FILE="$PROJECT_DIR/co-dm.service"

echo ""
echo "  ⛧  Co-DM Systemd Setup"
echo "  ═══════════════════════"
echo ""

# Verify we're in the right place
if [ ! -f "$PROJECT_DIR/server.js" ]; then
  echo "❌ ERROR: Run this script from inside ~/dark-pilgrimage/co-dm/"
  exit 1
fi

# Check .env exists
if [ ! -f "$PROJECT_DIR/.env" ]; then
  echo "❌ ERROR: .env file not found."
  echo "   Copy .env.template to .env and fill in your API keys first:"
  echo "   cp .env.template .env && nano .env"
  exit 1
fi

# Check required keys
if ! grep -q "GEMINI_API_KEY=" "$PROJECT_DIR/.env" || grep -q "GEMINI_API_KEY=your-" "$PROJECT_DIR/.env"; then
  echo "⚠️  WARNING: GEMINI_API_KEY looks unset in .env — edit before starting"
fi
if ! grep -q "HUBITAT_TOKEN=" "$PROJECT_DIR/.env" || grep -q "HUBITAT_TOKEN=your-" "$PROJECT_DIR/.env"; then
  echo "⚠️  WARNING: HUBITAT_TOKEN looks unset in .env — edit before starting"
fi

# Stop any existing running instance
echo "→ Stopping any existing co-dm container..."
docker compose down --timeout 10 2>/dev/null || true

# Stop old systemd service if running
sudo systemctl stop "$SERVICE_NAME" 2>/dev/null || true

# Update WorkingDirectory in service file to match actual path
echo "→ Configuring service file for path: $PROJECT_DIR"
sed "s|/home/dave/dark-pilgrimage/co-dm|$PROJECT_DIR|g" "$SERVICE_FILE" > /tmp/co-dm-configured.service

# Install service file
echo "→ Installing /etc/systemd/system/$SERVICE_NAME.service"
sudo cp /tmp/co-dm-configured.service "/etc/systemd/system/$SERVICE_NAME.service"
sudo systemctl daemon-reload

# Enable and start
echo "→ Enabling $SERVICE_NAME to start on boot..."
sudo systemctl enable "$SERVICE_NAME"

echo ""
echo "✅ Setup complete!"
echo ""
echo "  Start now:        sudo systemctl start co-dm"
echo "  Stop:             sudo systemctl stop co-dm"
echo "  Restart:          sudo systemctl restart co-dm"
echo "  Check status:     sudo systemctl status co-dm"
echo "  Live logs:        journalctl -u co-dm -f"
echo "  Dashboard:        https://192.168.0.198:3200"
echo "  Player bridge:    https://192.168.0.198:3202/player/{name}"
echo ""
echo "  Note: First start may take 3-5 min to build Docker image."
echo "        Watch with: journalctl -u co-dm -f"
echo ""
