const path = require('path');
const Orchestrator = require('./core/orchestrator');
const DashboardService = require('./services/dashboard/dashboard-service');
const PlayerBridgeService = require('./services/player-bridge/player-bridge-service');
const AudioService = require('./services/audio/audio-service');
const AIEngine = require('./services/ai/ai-engine');
const AtmosphereEngine = require('./services/atmosphere/atmosphere-engine');
const CharacterService = require('./services/characters/character-service');
const { loadConfig } = require('./utils/config-loader');

// Auto-discover session config: CLI arg > config/session-0.json > defaults only
const sessionConfigPath = process.argv[2]
  || path.join(__dirname, 'config', 'session-0.json');

const config = loadConfig(sessionConfigPath);

console.log('');
console.log('  \u26E7  THE DARK PILGRIMAGE \u2014 CO-DM AGENT');
console.log('  \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550');
console.log('');

const orchestrator = new Orchestrator(config);

orchestrator.register(new CharacterService());
orchestrator.register(new DashboardService());
orchestrator.register(new PlayerBridgeService());
orchestrator.register(new AudioService());
orchestrator.register(new AIEngine());
orchestrator.register(new AtmosphereEngine());

orchestrator.startAll().catch(err => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});

process.on('SIGINT', async () => { await orchestrator.stopAll(); process.exit(0); });
process.on('SIGTERM', async () => { await orchestrator.stopAll(); process.exit(0); });
process.on('uncaughtException', err => console.error('Uncaught exception:', err));
process.on('unhandledRejection', err => console.error('Unhandled rejection:', err));
