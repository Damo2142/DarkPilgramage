# Docker / Systemd Fix

## What Was Broken

`docker-compose.yml` was using `network_mode: host` with `restart: unless-stopped`.

When the container crashed, Docker immediately restarted it — but the kernel still had
ports 3200 and 3202 bound (TIME_WAIT state). The new container hit `EADDRINUSE` → crashed
→ Docker restarted → crash loop.

Additionally, if systemd was also managing Docker, **two restart systems were fighting each other**.

## What Was Fixed

### 1. `docker-compose.yml` — Bridge networking + no auto-restart

- Removed `network_mode: host`
- Added explicit port mappings: `3200:3200` and `3202:3202`
- Set `restart: "no"` — systemd now owns restarts (not Docker)

**Hubitat still works.** In bridge mode, outbound connections from the container to your
LAN (192.168.0.x) route through the host's default gateway. The container can still
reach `192.168.0.131` to control lights.

### 2. `co-dm.service` — Proper systemd unit

- Runs `docker compose up` in **foreground** (no `-d`) so systemd tracks the process
- Runs `docker compose down` on stop — clean shutdown
- `Restart=on-failure` with `RestartSec=15s` — waits 15s before retry (no crash loop)
- `StartLimitBurst=5` — gives up after 5 failures in 5 min (alerts you, stops hammering)
- Reads `.env` via `EnvironmentFile=` — no need to export keys in terminal

## Installation

```bash
# 1. Drop these files into your project
cd ~/dark-pilgrimage/co-dm
# (extract the zip here)

# 2. Make sure .env is filled in
cp .env.template .env   # if you haven't already
nano .env               # add GEMINI_API_KEY and HUBITAT_TOKEN

# 3. Run the setup script
bash setup-systemd.sh

# 4. Start the service
sudo systemctl start co-dm

# 5. Watch it come up (first time takes 3-5 min for Docker build)
journalctl -u co-dm -f
```

## Day-to-Day Commands

| Action | Command |
|--------|---------|
| Start | `sudo systemctl start co-dm` |
| Stop | `sudo systemctl stop co-dm` |
| Restart | `sudo systemctl restart co-dm` |
| Status | `sudo systemctl status co-dm` |
| Live logs | `journalctl -u co-dm -f` |
| Tail last 50 lines | `journalctl -u co-dm -n 50` |

## Running Without Docker (quick start)

The system still works without Docker if you just want to run directly:

```bash
cd ~/dark-pilgrimage/co-dm
source .env   # or export keys manually
node server.js config/session-0.json
```

Docker is used for reliable auto-start on boot and clean restarts.
